var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["f9e2ef76-f91a-4967-8b95-25fd127f46a9","25e3778f-b93e-4cda-a976-ac355b88af68","a762fad1-4911-4af9-9c38-3a13557c56ae","2492943d-3bdc-4b39-94dd-e630044922ae","d8a98809-1496-40e9-8ef9-704bf2a698bf","47dbe7b8-caef-472b-8ae7-501ce24dd335","aad66d67-1e0d-4de5-b779-674d8d0648e1","822cc632-a3dd-4cbb-9e1d-b3ab262fe250"],"propsByKey":{"f9e2ef76-f91a-4967-8b95-25fd127f46a9":{"name":"player1","sourceUrl":"assets/api/v1/animation-library/gamelab/pprrkT8zHUyC6q2DoLBo92Y_4r4kkTCW/category_people/blue_shirt_book.png","frameSize":{"x":136,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"pprrkT8zHUyC6q2DoLBo92Y_4r4kkTCW","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":136,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/pprrkT8zHUyC6q2DoLBo92Y_4r4kkTCW/category_people/blue_shirt_book.png"},"25e3778f-b93e-4cda-a976-ac355b88af68":{"name":"coin_gold_1","sourceUrl":"assets/api/v1/animation-library/gamelab/pUFPchUgZRoy5C6YtEEkLfSDmZWPxW.y/category_board_games_and_cards/coin_gold.png","frameSize":{"x":61,"y":61},"frameCount":1,"looping":true,"frameDelay":2,"version":"pUFPchUgZRoy5C6YtEEkLfSDmZWPxW.y","categories":["board_games_and_cards"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":61,"y":61},"rootRelativePath":"assets/api/v1/animation-library/gamelab/pUFPchUgZRoy5C6YtEEkLfSDmZWPxW.y/category_board_games_and_cards/coin_gold.png"},"a762fad1-4911-4af9-9c38-3a13557c56ae":{"name":"you win.png_1","sourceUrl":"assets/v3/animations/JmZ8pL-oKIZQN3vjqFs5PiF_CCEyMaTP7WTwDqA-yOg/a762fad1-4911-4af9-9c38-3a13557c56ae.png","frameSize":{"x":225,"y":225},"frameCount":1,"looping":true,"frameDelay":4,"version":"W3hZLNMfO0ww46am2aff.KIKWopE3n61","loadedFromSource":true,"saved":true,"sourceSize":{"x":225,"y":225},"rootRelativePath":"assets/v3/animations/JmZ8pL-oKIZQN3vjqFs5PiF_CCEyMaTP7WTwDqA-yOg/a762fad1-4911-4af9-9c38-3a13557c56ae.png"},"2492943d-3bdc-4b39-94dd-e630044922ae":{"name":"coin_gold_2","sourceUrl":"assets/api/v1/animation-library/gamelab/pUFPchUgZRoy5C6YtEEkLfSDmZWPxW.y/category_board_games_and_cards/coin_gold.png","frameSize":{"x":61,"y":61},"frameCount":1,"looping":true,"frameDelay":2,"version":"pUFPchUgZRoy5C6YtEEkLfSDmZWPxW.y","categories":["board_games_and_cards"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":61,"y":61},"rootRelativePath":"assets/api/v1/animation-library/gamelab/pUFPchUgZRoy5C6YtEEkLfSDmZWPxW.y/category_board_games_and_cards/coin_gold.png"},"d8a98809-1496-40e9-8ef9-704bf2a698bf":{"name":"heart1","sourceUrl":"assets/api/v1/animation-library/gamelab/NolfDXD9f49COunFY6Ops3IuWeUdWXbo/category_retro/retro_red_heart.png","frameSize":{"x":167,"y":143},"frameCount":1,"looping":true,"frameDelay":2,"version":"NolfDXD9f49COunFY6Ops3IuWeUdWXbo","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":167,"y":143},"rootRelativePath":"assets/api/v1/animation-library/gamelab/NolfDXD9f49COunFY6Ops3IuWeUdWXbo/category_retro/retro_red_heart.png"},"47dbe7b8-caef-472b-8ae7-501ce24dd335":{"name":"heart3","sourceUrl":"assets/api/v1/animation-library/gamelab/NolfDXD9f49COunFY6Ops3IuWeUdWXbo/category_retro/retro_red_heart.png","frameSize":{"x":167,"y":143},"frameCount":1,"looping":true,"frameDelay":2,"version":"NolfDXD9f49COunFY6Ops3IuWeUdWXbo","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":167,"y":143},"rootRelativePath":"assets/api/v1/animation-library/gamelab/NolfDXD9f49COunFY6Ops3IuWeUdWXbo/category_retro/retro_red_heart.png"},"aad66d67-1e0d-4de5-b779-674d8d0648e1":{"name":"heart2","sourceUrl":"assets/api/v1/animation-library/gamelab/NolfDXD9f49COunFY6Ops3IuWeUdWXbo/category_retro/retro_red_heart.png","frameSize":{"x":167,"y":143},"frameCount":1,"looping":true,"frameDelay":2,"version":"NolfDXD9f49COunFY6Ops3IuWeUdWXbo","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":167,"y":143},"rootRelativePath":"assets/api/v1/animation-library/gamelab/NolfDXD9f49COunFY6Ops3IuWeUdWXbo/category_retro/retro_red_heart.png"},"822cc632-a3dd-4cbb-9e1d-b3ab262fe250":{"name":"enemy","categories":["fantasy"],"frameCount":1,"frameSize":{"x":67,"y":93},"looping":true,"frameDelay":2,"jsonLastModified":"2021-01-05 19:06:29 UTC","pngLastModified":"2021-01-05 19:08:00 UTC","version":"wU6U7lGEWKljsvEeLN0.aIJ27WHBwKAr","sourceUrl":"assets/api/v1/animation-library/gamelab/wU6U7lGEWKljsvEeLN0.aIJ27WHBwKAr/category_fantasy/alienGreen_jump.png","sourceSize":{"x":67,"y":93},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/wU6U7lGEWKljsvEeLN0.aIJ27WHBwKAr/category_fantasy/alienGreen_jump.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var player = createSprite(200, 200);
player.setAnimation("player1");
player.scale = 0.25;
var coin = createSprite(48, 183);
coin.setAnimation("coin_gold_1");
var score = 0;
var coin2 = createSprite(178, 29);
coin2.setAnimation("coin_gold_2");
var heart1 = createSprite(60, 125);
heart1.setAnimation("heart1");
heart1.scale = 0.15;
var heart2 = createSprite(90, 125);
heart2.setAnimation("heart2");
heart2.scale = 0.15;
var heart3 = createSprite(120, 125);
heart3.setAnimation("heart3");
heart3.scale = 0.15;
var enemy = createSprite(217, 343);
enemy.setAnimation("enemy");
function draw() {
  background("white");
  fill("black");
  textSize(50);
  text(score, 50, 100);
  //Creates the player's movement
  if (keyDown("up")) {
    player.y = player.y - 10;
  }
  if (keyDown("down")) {
    player.y = player.y + 10;
  }
  if (keyDown("left")) {
    player.x = player.x - 10;
  }
  if (keyDown("right")) {
    player.x = player.x + 10;
  }
  //Tells the system that if the coin overlaps the player,
  //the coin will destroy and the score will be 1
  if (coin.overlap(player)) {
    coin.destroy();
    score=score+1;
    console.log(score);
  }
  if (coin2.overlap(player)) {
  score=score+1;  
  coin2.destroy();
  }
  //If collision is detected between the enemny and player, hearts
  //are deducted
  if (enemy.overlap(player)) {
    heart3.destroy();
    heart2.destroy();
  }
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
